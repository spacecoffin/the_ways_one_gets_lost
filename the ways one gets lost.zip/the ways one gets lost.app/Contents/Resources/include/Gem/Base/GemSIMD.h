#ifdef __GNUC__
# warning GemSIMD.h is deprecated - please include "Utils/SIMD.h" instead
#endif
#include "Utils/SIMD.h"

#ifdef __GNUC__
# warning GemPixImageLoad.h is deprecated - please include "Gem/ImageIO.h" instead
#endif
#include "Gem/ImageIO.h"

#ifdef __GNUC__
# warning Base/GemVersion.h is deprecated - please include "Gem/Version.h" instead
#endif
#include "Gem/Version.h"

#ifdef __GNUC__
# warning GemVector.h is deprecated - please include "Utils/Vector.h" instead
#endif
#include "Utils/Vector.h"

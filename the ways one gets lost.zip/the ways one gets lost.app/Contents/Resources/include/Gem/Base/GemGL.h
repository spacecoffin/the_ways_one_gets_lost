#ifdef __GNUC__
# warning GemGL.h is deprecated - please include "Gem/GemGL.h" instead
#endif
#include "Gem/GemGL.h"

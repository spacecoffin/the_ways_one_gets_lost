#ifdef __GNUC__
# warning GemPBuffer.h is deprecated - please include "Gem/PBuffer.h" instead
#endif
#include "Gem/PBuffer.h"

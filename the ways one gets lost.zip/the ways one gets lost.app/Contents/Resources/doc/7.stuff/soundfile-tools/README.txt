Here are some standard audio transformations packaged to work with mono
soundfiles.

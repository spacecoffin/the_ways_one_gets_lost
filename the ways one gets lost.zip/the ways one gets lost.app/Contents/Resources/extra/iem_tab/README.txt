This library extends the performance of miller puckette's pure data (pd).

iem_tab is written by Thomas Musil from IEM Graz Austria
 and it is compatible to miller puckette's pd-0.37-3 to pd-0.39-2.
see also LICENCE.txt, GnuGPL.txt.

The objects of iem_tab manipulate tables or arrays;
you can set constant, copy, fft, ifft, reverse, find minimum or maximum, compare, add, subtract, multiplicate, divide arrays.


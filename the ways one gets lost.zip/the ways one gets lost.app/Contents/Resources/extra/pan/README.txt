
A library of stereo panning algorithms from various sources.

TODO
====

- check F.Moore's Elements of Computer Music for panning algorithms

- write all_about_panning, including graphs and discussion from 
  http://www.csounds.com/ezine/autumn1999/beginners/

- include vbap~ and other advanced panning methods

XMLRPC external for PD -- Version 0.1.3b

Author: Thomas Grill t.grill [at] gmx.net
Maintainer: w.ritsch (for this release)


Docu:
  
  For Howto look at pd helppatches and pythonexample.

Requirements:
  
  I included xmlprc++ as library to prevent additional dependencies
  also this lib looks simple and clean not much to improve (w.ritsch)

  
Licence:
 
 LGPL see LICENSE.txt
 IEM - Institute of Electronic Music and Acoustics, Graz
 Inffeldgasse 10/3, 8010 Graz, Austria
 http://iem.at 

CHANGES: 
 
 V 0.1.3b, LICENSES added, post error removed.



